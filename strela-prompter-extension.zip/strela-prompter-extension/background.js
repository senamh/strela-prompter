chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'https://senamh.github.io/strela-prompter/' });
});
